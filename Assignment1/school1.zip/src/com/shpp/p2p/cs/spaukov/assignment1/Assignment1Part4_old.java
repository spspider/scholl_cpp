package com.shpp.p2p.cs.spaukov.assignment1;

public class Assignment1Part4_old extends spaukov_utils {
/*
we will create chess desk
0. square world
1. start from South-West
2. facing to East
3. any of world accepted(8x8,3*3)
4. no beepers in world no walls
5. the world can have 1 in width or 1 in height
6. Karel can go through any way.
 */

    public void run() throws Exception {
        //we will go to the East
        int Upmoves = 0;
        while (true) {//infinite loop
            if (Upmoves % 2 == 0) {//check if moves are Even (in up)
                moveAheadAndPutBeeperInEven(true);
            }else{
                moveAheadAndPutBeeperInEven(false);
            }

            turnheisLookNorth();//turn to North
            if (frontIsClear()) {//maybe this is the end of world
                move();
            } else {
                break;
            }
            turn1();
            moveUntilWall();
            turn2();
            Upmoves++;
            //int movesToEast2 = moveAheadAndPutBeeperInEven(false);
        }
    }


    private int moveAheadAndPutBeeperInEven(boolean Even) throws Exception {
        int moves = 0;
        boolean moveIt;
        while (frontIsClear()) {
            moveIt = true;
            checkIfEven(Even, moves, moveIt);
            moves++;
        }
        moveIt = false;
        if (!frontIsClear()) {
            checkIfEven(Even, moves, false);
        }
        return moves;
    }
    //turn Left
    public void turn1() throws Exception {
        turnLeft();
    }
    //turn Around
    public void turn2() throws Exception {
        turnLeft();
        turnLeft();
    }
    private void checkIfEven(boolean Even, int moves, boolean moveIt) throws Exception {
        if (!Even) {
            //System.out.println("moves"+moves);
            if (moves % 2 != 0) {//Odd
                putBeeper();
            }
            if (moveIt) {
                move();
            }
        }
        if (Even) {
            if (moves % 2 == 0) {//even
                putBeeper();
            }
            if (moveIt) {
                move();
            }
        }
    }
}
