package com.shpp.p2p.cs.spaukov.assignment1;

/*
main concept:
go to the end of the world, and put beepers in odd and even
no variables are used
 */
public class Assignment1Part4 extends spaukov_utils {
    public void run() throws Exception {
        doWorld();
    }

    private void doWorld() throws Exception {
        while (true) {//infinite loop
            if (!beepersPresent()) {
                putBeeper();
            }
            if (frontIsClear()) {

                move();
                while (beepersPresent()) {
                    pickBeeper();//remove another beepers from world.
                }
            } else {//now we are facing with odd world
                //we need to go to another line from there to:
                turnheisLookNorth();
                if (frontIsClear()) {
                    move();

                } else {
                    break;
                }
                makeAroundTurns();
                //to there

            }
            //this is the Even world
            if (frontIsClear()) {
                move();
                while (beepersPresent()) {
                    pickBeeper();//remove another beepers from world.
                }
            } else {
                turnheisLookNorth();
                if (frontIsClear()) {
                    move();
                } else {
                    break;
                }
                makeAroundTurns();
            }
        }
    }

    //i need to make around turns, to go from line to line
    private void makeAroundTurns() throws Exception {
        if (leftIsBlocked()) {
            turnheisLookEast();
        }
        if (rightIsBlocked()) {
            turnheisLookWest();
        }
    }

}
