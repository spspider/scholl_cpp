package com.shpp.p2p.cs.spaukov.assignment1;

import com.shpp.karel.KarelTheRobot;

public class Assigment1Part2_old extends KarelTheRobot {
    public void run() throws Exception {
        Assigment1Part2_old.Util util = new Assigment1Part2_old.Util();
        turnLeft();
        while (true) {//infinite
            PutIfThereNoBeeperAndStopOnTheWall(util);
            int heightDown = MoveZigZagToGround();
            int heightUp = MoveZigZagToUp();
            util.moveUntilWall();//return to start position
            util.turn(2);
            if (heightUp==999){//breakpoint
                PutIfThereNoBeeperAndStopOnTheWall(util);
                break;}
        }
    }

    private int MoveZigZagToUp() throws Exception {
        var height = 0;
        Util util = new Util();
        var noWall = 0;
        while (noWall == 0) {
            util.turn(3);
            System.out.println("turned right");
            move();
            util.turn(1);
            if (frontIsClear()) {
                System.out.println("turned left");
                move();
                //end of the maze need to go to last stone

                util.turn(1);
                System.out.println("turned left");
                if (!frontIsClear()) {
                    // util.turn(3);
                    System.out.println("wall");
                    util.turn(3);
                    height++;
                } else {
                    System.out.println("clear");
                    noWall = 1;
                    height--;
                    move();
                    util.turn(1);
                    move();
                    util.turn(1);
                    //break;
                }
            }else{
                util.turnheisLookSouth();
                noWall = 1;//exit from loop
                height=999;//exit from outer loop
            }
            System.out.println("north"+facingNorth()+"\nfacingEast()"+facingEast()+"\nfacingSouth()"+facingSouth()+"\nfacingWest()"+facingWest());
        }
        return height;
    }


    private int MoveZigZagToGround() throws Exception {
        var height = 0;
        Util util = new Util();
        while (true) {
            util.turn(3);
            if (frontIsClear()) {
                move();
                height++;
            } else {
                break;
            }
            util.turn(1);
            util.moveUntilWall();
        }
        return height;
    }

    private void PutIfThereNoBeeperAndStopOnTheWall(Util util) throws Exception {
        while (frontIsClear()) {
            util.IfBeepersPresentVoid();
            move();
        }
        util.IfBeepersPresentVoid();
    }

    private class Util {
        public void moveUntilBeepersPresent() throws Exception {
            while (!beepersPresent()) {
                move();
            }
        }

        public void IfBeepersPresentVoid() throws Exception {
            if (!beepersPresent()) {
                putBeeper();
            }
        }

        public void turn(int i) throws Exception {
            var n = 0;
            while (n < i) {
                turnLeft();
                n++;
            }
        }

        public void moveUntilWall() throws Exception {
            while (frontIsClear()) {
                move();
            }
        }

        public void turnheisLookNorth() throws Exception {
            while (!facingNorth()) {
                turnLeft();
            }
        }
        public void turnheisLookEast() throws Exception {
            while (!facingEast()) {
                turnLeft();
            }
        }
        public void turnheisLookWest() throws Exception {
            while (!facingWest()) {
                turnLeft();
            }
        }
        public void turnheisLookSouth() throws Exception {
            while (!facingSouth()) {
                turnLeft();
            }
        }
    }
}
