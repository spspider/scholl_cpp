package com.shpp.p2p.cs.spaukov.assignment1;

import com.shpp.karel.KarelTheRobot;

/*
we are going to collect newspaper
1. go to newspaper
2. pick it
3. return to home

 */
public class Assignment1Part1 extends KarelTheRobot {

    public void run() throws Exception {
        Util util = new Util();//create a new instance of helpful code
        MoveToBeeper(util);//move to beeper
        PickThisBeeper(util);//pick newspaper
        ReturnToStart(util); //return to home
    }

    private void ReturnToStart(Util util) throws Exception {
        util.turn2(); // turn around
        util.moveUntilWall();//move until wall is present
        util.turn3(); //turn right
        util.moveUntilWall();//move until wall is present
        util.turn3(); //turn right
    }

    private void PickThisBeeper(Util util) throws Exception {
        pickBeeper();
    }

    private void MoveToBeeper(Util util) throws Exception {
        util.moveUntilWall();//move until wall is present
        //turn 3 times for turn right
        util.turn3();
        move();
        turnLeft();
        util.moveUntilBeepersPresent();//move to beeper in loop
    }


    private class Util {
        public void moveUntilBeepersPresent() throws Exception {
            //if the no any beepers ahead - move to it
            while (!beepersPresent()) {
                move();
            }
        }
        //turn Left
        public void turn1() throws Exception {
            turnLeft();
        }
        //turn Around
        public void turn2() throws Exception {
            turnLeft();
            turnLeft();
        }
        //turn Right
        public void turn3() throws Exception {
            turnLeft();
            turnLeft();
            turnLeft();
        }

        public void turn(int i) throws Exception {
            //any way for turn to right i can use
            // turnLeft
            // turnLeft
            // turnLeft
            //but this is implementation of short-way code
            //and you know that i can rewrite it in any time
            // i don't use variables for Karel's logic(it is requirements from Karel book)
            var n = 0;
            while (n < i) {
                turnLeft();
                n++;
            }
        }

        public void moveUntilWall() throws Exception {
            while (frontIsClear()) {
                move();
            }
        }

    }
}

