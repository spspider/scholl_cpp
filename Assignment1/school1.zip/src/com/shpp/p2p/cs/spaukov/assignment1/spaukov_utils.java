package com.shpp.p2p.cs.spaukov.assignment1;

import com.shpp.karel.KarelTheRobot;

public class spaukov_utils extends KarelTheRobot {
    //deprecated
    public void moveUntilBeepersPresent() throws Exception {
        while (!beepersPresent()) {
            move();
        }
    }

    //deprecated
    public void IfBeepersPresentVoid() throws Exception {
        if (!beepersPresent()) {
            putBeeper();
        }
    }

    //turn
    public void turn(int i) throws Exception {
        var n = 0;
        while (n < i) {
            turnLeft();
            n++;
        }
    }

    //move uintil wall (step are not used,because it prohibited to use variables
    public void moveUntilWall() throws Exception {
        //var step = 0;
        while (frontIsClear()) {
            move();
            //step++;
        }
        //  return step;
    }

    //is it look to North?no? turn it!
    public void turnheisLookNorth() throws Exception {
        while (notFacingNorth()) {
            turnLeft();
        }
    }

    //is it look to East?no? turn it!
    public void turnheisLookEast() throws Exception {
        while (notFacingEast()) {
            turnLeft();
        }
    }

    //is it look to West?no? turn it!
    public void turnheisLookWest() throws Exception {
        while (notFacingWest()) {
            turnLeft();
        }
    }

    //is it look to South?no? turn it!
    public void turnheisLookSouth() throws Exception {
        while (notFacingSouth()) {
            turnLeft();
        }
    }

    //deprecated
    public void PickBeeperIfPresent() throws Exception {
        if (beepersPresent()) {
            pickBeeper();
        }
    }
}
