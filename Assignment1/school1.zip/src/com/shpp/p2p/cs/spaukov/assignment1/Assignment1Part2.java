package com.shpp.p2p.cs.spaukov.assignment1;

import com.shpp.karel.KarelTheRobot;

/*
this is the code for Karel's algorithm for stones, witch are not completed
 */
public class Assignment1Part2 extends KarelTheRobot {
    public void run() throws Exception {
        //create useful copy of helpful class
        Assignment1Part2.Util util = new Assignment1Part2.Util();
        while (true) {//infinite loop
            //check he is the turned North?
            util.turnheisLookNorth();
            //go to wall and add beepers,if there
            PutIfThereNoBeeperAndStopOnTheWall(util);
        /*
        now we need to turn Karel face to South and move to the edge of the world
         */
            util.turnheisLookSouth();
            util.moveUntilWall();
            util.turnheisLookEast();
            //if the is no to go, the program will be completed
            if (!frontIsClear()) {
                break;//exit from cycle
            }
            //we know that we need to go through 4 steps, to avoid repeats, mean
            //move();
            //move();
            //move();
            //move();
            //i catch all of this in one cycle

//            for (int i = 0; i < 4; i++) {
//                if (frontIsClear()) {//avoid possible stones
//                    move();
//                } else {
//                    //only for debugging purposes, you can ignore that
//                    System.out.println("ERROR (frontIsClear):" + frontIsClear());
//                    break;
//                }
//            }

            if (frontIsClear()) {//avoid possible stones
                move();
            } else {
                //only for debugging purposes, you can ignore that
                 break;
            }
            if (frontIsClear()) {//avoid possible stones
                move();
            } else {
                //only for debugging purposes, you can ignore that
                break;
            }
            if (frontIsClear()) {//avoid possible stones
                move();
            } else {
                //only for debugging purposes, you can ignore that
                break;
            }
            if (frontIsClear()) {//avoid possible stones
                move();
            } else {
                //only for debugging purposes, you can ignore that
                break;
            }

        }

    }

    //we need to put beepers and stop if there wall ahead
    private void PutIfThereNoBeeperAndStopOnTheWall(Assignment1Part2.Util util) throws Exception {
        while (frontIsClear()) {
            util.IfBeepersPresentVoid();//check if there under robot is beeper
            move();//move
        }
        // the problem is:
        // after move, and if there front in not clear, Karel ignore putting beeper
        //to do this we need to put it again
        util.IfBeepersPresentVoid();

    }


    private class Util {
        //deprecated
        public void moveUntilBeepersPresent() throws Exception {
            while (!beepersPresent()) {
                move();
            }
        }

        //if there beeper, put it
        public void IfBeepersPresentVoid() throws Exception {
            if (!beepersPresent()) {
                putBeeper();
            }
        }

        //deprecated
        public void turn(int i) throws Exception {
            var n = 0;
            while (n < i) {
                turnLeft();
                n++;
            }
        }
        //turn Left
        public void turn1() throws Exception {
            turnLeft();
        }
        //turn Around
        public void turn2() throws Exception {
            turnLeft();
            turnLeft();
        }
        //turn Right
        public void turn3() throws Exception {
            turnLeft();
            turnLeft();
            turnLeft();
        }
        //if there no walls, go ahead!!!
        public void moveUntilWall() throws Exception {
            while (frontIsClear()) {
                move();
            }
        }

        //is it look to North?no? turn it!
        public void turnheisLookNorth() throws Exception {
            while (!facingNorth()) {
                turnLeft();
            }
        }
        //is it look to East?no? turn it!
        public void turnheisLookEast() throws Exception {
            while (!facingEast()) {
                turnLeft();
            }
        }
        //is it look to West?no? turn it!
        public void turnheisLookWest() throws Exception {
            while (!facingWest()) {
                turnLeft();
            }
        }
        //is it look to South?no? turn it!
        public void turnheisLookSouth() throws Exception {
            while (!facingSouth()) {
                turnLeft();
            }
        }
    }
}
