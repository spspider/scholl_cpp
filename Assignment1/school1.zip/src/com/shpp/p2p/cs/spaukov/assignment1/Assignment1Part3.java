package com.shpp.p2p.cs.spaukov.assignment1;

import com.shpp.karel.KarelTheRobot;

public class Assignment1Part3 extends KarelTheRobot {
    /*
     *
     * main concept of the finding middle point
     * to throw the beepers, and bouncing from it
     *
     *
     */
    public void run() throws Exception {
        Assignment1Part3.Util util = new Assignment1Part3.Util();
        //lets check if we are looking to the East
        util.turnheisLookEast();
        //and make first turn from beeper
        putBeeper();
        //now we do some magic and remove all beepers ahead, also we find a wall
        util.moveUntilWallAndRemoveBeepers();
        //turn around
        util.turn2();
        //check if there no beepers put it
        if (!beepersPresent()) {
            putBeeper();
        }
        //i like infinite loops)
        while (true) {
            //move it until front is clear
            util.moveIfFrontClear();
            //move again, because we puttied beeper
            util.moveUntilBeepersPresent();
            //turn around(turnLeft turnLeft)
            util.turn2();
            //move it until front is clear
            util.moveIfFrontClear();
            //check if there any beepers?
            if (!beepersPresent()) {
                putBeeper();
            }
            util.moveIfFrontClear();
            if (beepersPresent()) {
                util.turn2();
                util.moveIfFrontClear();
                putBeeper();
                break;
                //middle point found! now we need to clear the world
            }


        }
// cleaning the world:
        util.moveUntilWallAndRemoveBeepers();//all beepers should be removed
        util.turn2();
        while (frontIsClear()) {
            if (beepersPresent()) {
                pickBeeper();
            }
            util.moveIfFrontClear();
        }
        if (beepersPresent()) {
            pickBeeper();
        }


    }


    private class Util {
        //move until beepers is present
        public void moveUntilBeepersPresent() throws Exception {
            while (!beepersPresent()) {
                move();
            }
        }

        //turn (deprecated)
        public void turn(int i) throws Exception {
            var n = 0;
            while (n < i) {
                turnLeft();
                n++;
            }
        }
        //turn Left
        public void turn1() throws Exception {
            turnLeft();
        }
        //turn Around
        public void turn2() throws Exception {
            turnLeft();
            turnLeft();
        }
        //turn Right
        public void turn3() throws Exception {
            turnLeft();
            turnLeft();
            turnLeft();
        }
        public void moveUntilWallAndRemoveBeepers() throws Exception {

            while (frontIsClear()) {
                move();
                while (beepersPresent()) {
                    //removing all beepers,were was facing
                    pickBeeper();
                }
            }

        }

        //is it look to East?no? turn it!
        public void turnheisLookEast() throws Exception {
            while (notFacingEast()) {
                turnLeft();
            }
        }


        public void moveIfFrontClear() throws Exception {
            if (frontIsClear()) {
                move();
            }
        }
    }
}
